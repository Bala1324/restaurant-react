const router = require('express').Router();
const moment = require('moment');
const tableBookingSchema = require('../model/tableBooking.model');
// const { authVerify, isAdmin, isUser } = require("../middleware/auth");



router.post('/table-book', async (req, res) => {
    try {
        const patio = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9', 't10']
        const Inside = ['t11', 't12', 't13', 't14', 't15', 't16', 't17']
        const Bar = ['t18', 't19', 't20', 't21', 't22', 't23', 't24', 't25', 't26', 't28']
        const Any = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9', 't10', 't11', 't12', 't13', 't14', 't15', 't16', 't17', 't18', 't19', 't20', 't21', 't22', 't23', 't24', 't25', 't26', 't28']

        const { date, time, location, person } = req.body
        // const dbData = await tableBookingSchema.find()
        // if (dbData.length != 0) {

        const findData = await tableBookingSchema.find({ date, time })
        // console.log("dbData", dbData)
        if (findData.length != 0) {
            return res.status(200).json({ status: true, "message": "Table Already Booked In This Slot, Please book different date and time!" })
        }




        // tableBookingSchema.aggregate([
        //     {
        //         "$project": {
        //             "passengerId": 1
        //         }
        //     }
        // ]).pretty();


        const data = new tableBookingSchema({ date, time, location, person });
        const result = await data.save();

        // } 


        // console.log(result)
        if (result) {
            return res.status(200).json({ status: true, "message": "Table Booked Successfully" })
        } else {
            return res.status(200).json({ status: false, "message": "Somthing went wrong!" })
        }

    } catch (error) {
        console.log(error.message);
        return res.status(400).json({ "status": 'failure', 'message': error.message })
    }
});





module.exports = router;